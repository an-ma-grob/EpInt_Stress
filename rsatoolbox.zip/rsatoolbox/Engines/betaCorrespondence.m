function betas = betaCorrespondence_loop_togetherFA
%
%  betaCorrespondence.m is a simple function which should combine
%  three things: preBeta:	a string which is at the start of each file
%  containing a beta image, betas:	a struct indexed by (session,
%  condition) containing a sting unique to each beta image, postBeta:	a
%  string which is at the end of each file containing a beta image, not
%  containing the file .suffix
% 
%  use "[[subjectName]]" as a placeholder for the subject's name as found
%  in userOptions.subjectNames if necessary For example, in an experment
%  where the data from subject1 (subject1 name)  is saved in the format:
%  subject1Name_session1_condition1_experiment1.img and similarly for the
%  other conditions, one could use this function to define a general
%  mapping from experimental conditions to the path where the brain
%  responses are stored. If the paths are defined for a general subject,
%  the term [[subjectName]] would be iteratively replaced by the subject
%  names as defined by userOptions.subjectNames.
% 
%  note that this function could be replaced by an explicit mapping from
%  experimental conditions and sessions to data paths.
% 
%  Cai Wingfield 1-2010
%__________________________________________________________________________
% Copyright (C) 2010 Medical Research Council

nconditions = 49;

for cond = 1:nconditions
    if cond > 0 && cond < 4
        betas(1,cond).identifier = char(strcat('\', 'spmT_000',string(cond),'.nii'));
    end
    if cond > 5 && cond < 10
        betas(1,cond-2).identifier = char(strcat('\', 'spmT_000',string(cond),'.nii'));
    end
    if cond > 9 && cond < 12
        betas(1,cond-2).identifier = char(strcat('\', 'spmT_00',string(cond),'.nii'));
    end
    if cond > 13 && cond < 20
        betas(1,cond-4).identifier = char(strcat('\', 'spmT_00',string(cond),'.nii'));
    end
    if cond > 21 && cond < 28
        betas(1,cond-6).identifier = char(strcat('\', 'spmT_00',string(cond),'.nii'));
    end
    if cond > 29 && cond < 36
        betas(1,cond-8).identifier = char(strcat('\', 'spmT_00',string(cond),'.nii'));
    end
    if cond > 37 && cond < 44
        betas(1,cond-10).identifier = char(strcat('\', 'spmT_00',string(cond),'.nii'));
    end
    if cond > 45 && cond < 49
        betas(1,cond-12).identifier = char(strcat('\', 'spmT_00',string(cond),'.nii'));
    end
end          


end%function
